title: 前端常用的API总结
date: '2021-09-26 13:17:02'
updated: '2021-09-26 13:17:02'
tags: [待分类]
permalink: /articles/2021/09/26/1632633422467.html
---
Javascript对象数组去重

```javascript
let hash = {} //对象数组去重
companyOption = companyOption.reduce((item, next)=>{
hash[next.value] ? '' : hash[next.value] = item.push(next)
return item
},[])
```
