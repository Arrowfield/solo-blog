title: Nginx服务器的优化配置
date: '2021-09-25 17:43:55'
updated: '2021-09-25 21:29:24'
tags: [待分类]
permalink: /articles/2021/09/25/1632563035420.html
---
开启压缩gzip

[参考二](https://www.cnblogs.com/starluke/p/12078058.html)

[参考三](https://ld246.com/article/1499149124090#toc_h5_5)

```shell
# 开启gzip
gzip on;

# 启用gzip压缩的最小文件；小于设置值的文件将不会被压缩
gzip_min_length 1k;

# gzip 压缩级别 1-10 
gzip_comp_level 2;

# 进行压缩的文件类型。

gzip_types text/plain application/javascript application/x-javascript text/css application/xml text/javascript application/x-httpd-php image/jpeg image/gif image/png;

# 是否在http header中添加Vary: Accept-Encoding，建议开启
gzip_vary on;
```

开启缓存

对设置了反向代理的进行缓存

```shell
worker_processes  1;
events {
  worker_connections  1024;
}
http {
  include       mime.types;
  default_type  application/octet-stream;
  sendfile        on;
  #tcp_nopush     on;
  #keepalive_timeout  0;
  keepalive_timeout  65;
  include nginx_proxy.conf;
  proxy_cache_path  /data/nuget-cache levels=1:2 keys_zone=nuget-cache:20m max_size=50g inactive=168h;
  #gzip  on;
  server {
    listen       8081;
    server_name  xxx.abc.com;
    location / {
      proxy_pass http://localhost:7878;
      add_header  Cache-Control  max-age=no-cache;
    }
    location ~* \.(css|js|png|jpg|jpeg|gif|gz|svg|mp4|ogg|ogv|webm|htc|xml|woff)$ {
      access_log off;
      add_header Cache-Control "public,max-age=30*24*3600";
      proxy_pass http://localhost:7878;
    }
    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
      root   html;
    }
  }
}
```

重启docker中的nginx，并且映射缓存目录

```shell
docker run -d -p 80:80 -p 443:443 --name nginx \
-v /nginx/conf/nginx.conf:/etc/nginx/nginx.conf \
-v /nginx/conf/conf.d:/etc/nginx/conf.d \
-v /nginx/html:/usr/share/nginx/html \
-v /nginx/logs:/var/log/nginx \
-v /nginx/conf.d/default.conf:/etc/nginx/conf.d/default.conf \
-v /nginx/ssl:/ssl/ \
-v /nginx/cache:/nginx/cache \
-d --rm nginx
```

![image.png](https://b3logfile.com/file/2021/09/image-81be38c8.png)

> 转载说明：来自``博客园``|[nginx缓存配置及开启gzip压缩](https://www.cnblogs.com/tugenhua0707/p/10841267.html)
