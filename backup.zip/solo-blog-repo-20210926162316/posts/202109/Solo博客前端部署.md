title: Solo博客前端部署
date: '2021-09-19 17:50:21'
updated: '2021-09-25 17:09:01'
tags: [Solo, Docker]
permalink: /articles/2021/09/19/1632045021767.html
---
![](https://b3logfile.com/bing/20200831.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

这是第二次更新这篇文档了，2020年6月份的时候，有尝试搭建过一次自己的博客网站。当时可以使用学生优惠，云服务器大概就50多，然后就下单第一次购买了云服务器。接下来也购买了域名，然后走备案流程，大概7天备案号就可以下来。云服务器是今年6月份过期的，之前的数据不多，服务器资源释放后，啥也没有了。自己的文笔不太好，也不太会写文章，看着别的博主写的文章，然后跟着他们写的，这也是第一次写这些大段的话，所以废话有点多，见谅。

刚开始时，是使用自己写的代码搭建的博客平台，前端样式，管理端是使用的element-admin进行二次修改的，后端的接口是使用Springboot的开发的。不过这样耗费的时间有点多，还要兼顾浏览器的兼容。后来在网上看，觉得Solo使用docker搭建的博客，比较美观，主题皮肤挺好看，看着另外一个博主写的文章，跟着他的步骤，最后把网站就搭建好了。

个人觉得Solo的管理系统的富文本系统非常好用。下面介绍下Solo博客的搭建流程，以及遇到的坑。

# 购买服务器

首先我们需要购买自己的ECS服务器，[阿里云](https://ecs-buy.aliyun.com/wizard/?accounttraceid=d2c0da15e27d4ad293bec06833c5164erwkr#/prepay/cn-shenzhen)，腾讯云，新浪云，[亚马逊](https://aws.amazon.com/cn/)都行,个人推荐阿里云，后期需要备案在阿里云也比较方便，亚马逊似乎要绑定个人信用卡，我现在也没有办信用卡😂 。

![image.png](https://b3logfile.com/file/2021/09/image-a73eaad1.png)

因为现在超过24岁了，不能使用[学生优惠](https://www.aliyun.com/daily-act/ecs/activity_selection?spm=5176.8789780.J_3965641470.1.5fcd45b5WHtFEm®ionId=cn-hangzhou)，因此买了突发性能实例t6配置2核2G1M，一年大概花费了300。大学期间用来学习的，似乎现在可以使用免费使用的策略。系统的话，推荐使用CentOS8.4，也是linux最新版本了。内存最好还是2G的比较稳定，个人之前买的1G的内存，跑个docker，系统很容易卡死，重启也比较慢，不过可以升降配，于是我自己升级成2g，日常运行也会跑到占用70%。对vps国外服务器感兴趣的可以参考[vultr](https://www.vultr.com/)等服务器

# 域名购买

[万网](https://wanwang.aliyun.com/)上.com，.cn的域名比较贵，.top的估计是最便宜的了。阿里云的域名，基本上都会备案，不要购买些奇奇怪怪的域名，必须是[可备案的](http://xn--eqrt2g.xn--vuq861b/)，备案后我们博客就可通过域名访问，没备案时就会提示，如果服务器是国外的，似乎就不用备案了。不进行备案，大概率会封掉80，443端口

![image.png](https://b3logfile.com/file/2021/09/image-51fa1ea7.png)

# 域名解析与备案

去年有进行过一次备案流程，大概话了6到7个工作日，第一个大的流程是阿里云的初审，需要提供身份证的正反面的照片，要提供居住证或者工作地区的社保卡，不同省份的备案流程也可能不同，比如我在深圳工作，去年不用写备案承诺书，今年就要求需要下载备案承诺书文档，于是我将通信地址改成老家，就不需要了。然后工作人员可能会要求使用钉钉进行视频核验流程，或者录制承诺视频发工作人员邮箱，才能保证初审的通过，然后是[信息核验](https://beian.miit.gov.cn/#/Integrated/index)，以及管局终审。[查看备案流程以及结果](https://beian.aliyun.com/pcContainer/myorder)

[域名解析](https://dns.console.aliyun.com/?spm=5176.100251.111252.17.5fc34f15nv5agi#/dns/setting/zipblog.top)流程很快，就1，2分钟，就可以搞定。

![image.png](https://b3logfile.com/file/2021/09/image-82effb14.png)

# 为服务器安装系统

购买服务器后，会默认装上你选择的相应的系统，会要求设置用户登录密码，以及ssh服务的登录账号以及密码，通常账号名是root，为避免后期的麻烦，服务器购买后，需要开放安全组部分端口，入方向默认会开放22，80。然后我们可能需要开放3306，443，8080，3000。<span style="color:red">22端口可以让我们使用window的[xshell](https://www.netsarang.com/zh/xshell/)连接远程服务器</span>，这块有个坑

> 我弄了好几天，就是家的电信网络将22的端口给封了。我使用公司的网络和手机的移动流量，都是可以使用22端口访问阿里云远程服务器的，就是家里的wifi不行，后来网上找资料，说是由于端口被封，真的坑了好几天，于是我将远程服务器的ssh服务端口改成了其他的，比如22345就可以了。同时安全组需要放开22345端口的入方向。

# Linux安装[Docker](https://www.runoob.com/docker/docker-tutorial.html)

直接使用yum安装，简单快捷，会自动配置相应的环境的变量，安装即用。除了自己安装的，千万不要随便删系统文件，我就删一次，最后导致系统崩溃，只能回滚磁盘，然后就导致我之前写的部分文章全部没了😭 。

```shell
# 安装docker
yum -y install docker 
# 启动docker后台服务
service docker start
# 测试运行
docker run hello-world
```

出现welcome就说明安装成功了

![image.png](https://b3logfile.com/file/2021/09/image-5936dd78.png)

# Docker安装MySQL

```shell
# 安装mysql:5.6,直接docker run 他会自动去官方镜想下载
# MYSQL_ROOT_PASSWORD=你的数据库密码
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.6

# docker安装的mysql默认允许远程连接，可以使用Navicat等软件连接数据库
# 进入容器mysql
docker exec -it mysql bash

# 进入数据库 p后面跟你的密码
mysql -uroot -pXXX

# 创建数据库(数据库名:solo;字符集utf8mb4;排序规则utf8mb4_general_ci)
create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
# 出现Query OK, 1 row affected (0.00 sec)表示成功
#退出数据库
exit
#退出容器
exit
```

# Docker安装[Solo](https://b3log.org/solo/#docs)视频教程

拉去Solo博客的最新镜像

```shell
docker pull b3log/solo
```

直接运行以下命令

```shell
docker run --detach --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="123456" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
--rm \
-v /skins/:/opt/solo/skins/ \
b3log/solo --lute_http=http://127.0.0.1:8249 --listen_port=80 --server_scheme=http --server_host=120.78.171.206
```

上面的命令建议手敲，免得出错，参数说明

+ --env JDBC_PASSWORD="123456" 将123456换成你的密码
+ --listen_port=80 监听的端口
+ --server_scheme=http 请求方式，暂时使用http，后面我们会换成https
+ --server_host=120.78.171.206 你的域名，如果你没有域名可以写ip地址
+ --rm因为这个容器后面要删掉，带上rm会省很多事。

执行上诉的命令，如果执行docker ps出现solo，即是运行成功，访问你配置的ip，即可，可能出现的错误有

1. 数据库没有建，需要使用[Navicat 15](https://www.navicat.com.cn/)，建立新的数据库
2. [第三方皮肤](https://b3log.org/solo/#docs)挂载，需要从github中下载[Solo原有的皮肤](https://github.com/88250/solo/tree/master/src/main/resources/skins)后，放到自定义目录中，然后再将第三方皮肤放入同级目录，才可以运行成功。
3. 如果去掉-rm，执行docker ps -a的时候，就可以看到执行失败的solo容器。

# 安装Nginx

安装nginx前，我们现在本地建立几个文件，用于存放nginx的配置文件等

```shell
# 切换到服务器根目录
cd /
# 创建文件
mkdir nginx /nginx/conf /nginx/conf.d /nginx/conf.d/cert /nginx/html/web  /nginx/logs /nginx/html
```

![截屏20210923下午7.52.05.png](https://b3logfile.com/file/2021/09/截屏2021-09-23_下午7.52.05-d21b197e.png)

目录名字可以自行更换,与挂载的时候保持一致就好了

+ nginx 用于存放docker下nginx自定义文件
+ /nginx/conf 存放nginx配置文件
+ /nginx/log 存放nginx日志文件
+ /nginx/html 存放nginx访问的资源文件
+ /nginx/conf.d 存放ssl证书和默认配置

```shell
server{
  listen 3000;
  # 域名还没有备案成功的时候
  server_name 120.78.171.206;
  location / {
        root   /usr/share/nginx/html/web;
        # root   /usr/nginx/html;
        index  index.html index.htm;
        # autoindex  on;
	      try_files $uri $uri/ /index.html;
        # proxy_pass http://121.199.58.113:8080;
        #try_files $uri /index/map/page.html;
    }
    #location /api {
      #proxy_pass http://120.78.171.206:8090;
    #}
}
```

然后使用以下的脚步进行相关的挂载，通常我们更新的文件是default.conf文件和ssl证书，html中我又新建了web文件，有时候我们需要区分admin和web，因此我就单独建了文件夹

可以导出自带的配置文件

+ docker cp nginx:/etc/nginx/nginx.conf /nginx/conf/nginx.conf 导出配置文件nginx.conf
+ docker cp nginx:/etc/nginx/conf.d  /nginx/conf/conf.d 导出配置为你nginx.conf
+ 执行 docker stop nginx，会自动删除现在的nginx容器，然后执行如下命令重新启动一个nginx容器

挂载自己的配置文件

```shell
docker run \
--name=nginx01 \
-p 3000:3000 \
-v /nginx/conf/nginx.conf:/etc/nginx/nginx.conf \
-v /nginx/logs:/var/log/nginx \
-v /nginx/html:/usr/share/nginx/html \
-v /nginx/conf.d/default.conf:/etc/nginx/conf.d/default.conf \
-d --rm nginx
```

![image.png](https://b3logfile.com/file/2021/09/image-032d3471.png)

显示上方流程，即挂载成功

# 申请ssl证书，升级到https

阿里云还是一如既往的有[免费的证书](https://yundun.console.aliyun.com/?spm=5176.2020520101.top-nav.dbutton.59044df5phmZCv&p=cas#/certExtend/free)直接，绑定就好，拿来试手

![image.png](https://b3logfile.com/file/2021/09/image-9e623aef.png)

将下发的.key，.pem签名证书放到文件夹下，进行对应的配置挂载即可

## 配置nginx配置文件

```shell


server {
    listen       443 ssl;
    server_name  zipblog.top  ;

	  ssl on;

  ssl_certificate /ssl/6315565_zipblog.top.pem;

 ssl_certificate_key /ssl/6315565_zipblog.top.key;

  ssl_session_timeout 5m;

  ssl_protocols TLSv1 TLSv1.1 TLSv1.2;

  ssl_ciphers ALL:!ADH:!EXPORT56:RC4+RSA:+HIGH:+MEDIUM:+LOW:+SSLv2:+EXP;

  ssl_prefer_server_ciphers on;




    #charset koi8-r;
    #access_log  /var/log/nginx/log/host.access.log  main;
 
    location / {
        root   /usr/share/nginx/html/web;
        # root   /usr/nginx/html;
        index  index.html index.htm;
        # autoindex  on;
	      try_files $uri $uri/ /index.html;

        # proxy_pass http://121.199.58.113:8080;
  
        #try_files $uri /index/map/page.html;
    }

    #location /api {
     # proxy_pass http://arrowfield.top:8080;
   # }
 
    #error_page  404              /404.html;
 
    # redirect server error pages to the static page /50x.html
    #
    # error_page   500 502 503 504  /50x.html;
    # location = /50x.html {
    #     root   /usr/share/nginx/html;
    # }
 
    # proxy the PHP scripts to Apache listening on 127.0.0.1:80
    #
    #location ~ \.php$ {
    #    proxy_pass   http://127.0.0.1;
    #}
 
    # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
    #
    #location ~ \.php$ {
    #    root           html;
    #    fastcgi_pass   127.0.0.1:9000;
    #    fastcgi_index  index.php;
    #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
    #    include        fastcgi_params;
    #}
 
    # deny access to .htaccess files, if Apache's document root
    # concurs with nginx's one
    #
    #location ~ /\.ht {
    #    deny  all;
    #}

}



server{

  listen 80;



  server_name zipblog.top;

  rewrite ^(.*) https://$host$1 permanent;

}
```

不重要的部分直接省略了，可以根据自己的需要进行调整

由于我们现在用的nginx容器并未监听443端口，所以需要删除现在的容器，重新启动一个新的nginx容器

```shell
docker stop nginx  # 停止容器
docker rm nginx # 删除容器
# 启动新的
docker run -d -p 80:80 -p 443:443 --name nginx \
-v /nginx/conf/nginx.conf:/etc/nginx/nginx.conf \
-v /nginx/conf/conf.d:/etc/nginx/conf.d \
-v /nginx/html:/usr/share/nginx/html \
-v /nginx/logs:/var/log/nginx \
-v /nginx/conf.d/default.conf:/etc/nginx/conf.d/default.conf \
-v /nginx/ssl:/ssl/ \
-d --rm nginx
```

+ -p 443:443 监听443端口
+ -v /nginx/ssl:/ssl/ 挂载ssl证书目录

![截屏20210923下午7.54.39.png](https://b3logfile.com/file/2021/09/截屏2021-09-23_下午7.54.39-4dcf05f2.png)

## 腾讯云

## 阿里云

## 其他平台

## 上传证书

# 将solo通过nginx方向代理实现https访问

让solo还是跑在8080端口上，通过nginx代理到443端口即可，由于我们上面启动solo时添加了 --rm参数，只需要 docker stop solo即可自动删除solo容器，然后我们重新启动一个solo容器

```shell
docker run --detach --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="123456" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
-v /skins/:/opt/solo/skins/ \
--rm b3log/solo --listen_port=8080 --server_scheme=https --server_host=zipblog.top --server_port=
```

+ --server_scheme=http换成 --server_scheme=https即可
+ --server_port：最终访问端口，使用浏览器默认的 80 或者 443 的话值留空即可

然后我们去配置nginx配置文件，实现nginx反向代理

```shell
upstream backend {
    server zipblog.top:8080; # Solo 监听端口
}

server {
    listen       443 ssl;
    server_name  zipblog.top  ;

    access_log off;
	  ssl on;

  ssl_certificate /ssl/6315565_zipblog.top.pem;

 ssl_certificate_key /ssl/6315565_zipblog.top.key;

  ssl_session_timeout 5m;

  ssl_protocols TLSv1 TLSv1.1 TLSv1.2;

  ssl_ciphers ALL:!ADH:!EXPORT56:RC4+RSA:+HIGH:+MEDIUM:+LOW:+SSLv2:+EXP;

  ssl_prefer_server_ciphers on;




    #charset koi8-r;
    #access_log  /var/log/nginx/log/host.access.log  main;
 



    location / {
        proxy_pass http://backend$request_uri;
        proxy_set_header  Host $http_host;
        proxy_set_header  X-Real-IP $remote_addr;
        client_max_body_size  10m;
    }



    #location /api {
     # proxy_pass http://arrowfield.top:8080;
   # }
 
    #error_page  404              /404.html;
 
    # redirect server error pages to the static page /50x.html
    #
    # error_page   500 502 503 504  /50x.html;
    # location = /50x.html {
    #     root   /usr/share/nginx/html;
    # }
 
    # proxy the PHP scripts to Apache listening on 127.0.0.1:80
    #
    #location ~ \.php$ {
    #    proxy_pass   http://127.0.0.1;
    #}
 
    # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
    #
    #location ~ \.php$ {
    #    root           html;
    #    fastcgi_pass   127.0.0.1:9000;
    #    fastcgi_index  index.php;
    #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
    #    include        fastcgi_params;
    #}
 
    # deny access to .htaccess files, if Apache's document root
    # concurs with nginx's one
    #
    #location ~ /\.ht {
    #    deny  all;
    #}

}




server{

  listen 80;

  server_name zipblog.top;

  rewrite ^(.*) https://$host$1 permanent;

}

# 替换上面部分即可
# 按esc，然后输入:wq保持退出
```

> 注意！！！Nginx反代理上面的方式可能出现问题参考[Nginx反代](https://hacpai.com/article/1492881378588#NGINX-%E5%8F%8D%E4%BB%A3)

重启nginx，docker restart nginx

# 后记

## 皮肤挂载

+ 在你的服务器上创建一个目录用于存放皮肤，比如我的 /dockerData/solo/skins/
+ 然后将你要挂载的皮肤放到上面那个目录下
+ 最后删除当前容器 重新启动一个容器，添加参数 --v /dockerData/solo/skins/:/opt/solo/skins/，这个添
+ 加时要注意位置，要添加到 b3log/solo --listen... 的上面一排
+ 使用挂载皮肤时，默认会使用 Pingsu,

## 皮肤推荐

原作者开源了两款皮肤 [solo-nexmoe](https://hacpai.com/article/1566468138289)，因为我很懒的原因，solo-star没有手机端，所以你可以多挂载一款皮肤们比如官方皮肤 Pinghsu，如果你没有这款皮肤就会报错，没有请前往[solo-skins](https://github.com/b3log/solo-skins)下载

## 数据库占用内存过大优化

由于我们购买的服务器是内存只有1G，然后docker安装的mysql虽然很快，但是实际上占用内存非常大，之前服务器在腾讯云的时候就经常挂掉，排查了很久才发现是docker下mysql的问题，迁移到阿里云后倒是没出先挂掉的问题，但是服务器内存占用也一直在90%以上，所以我们对mysql容器进行一些优化。
由于容器内不能vim，所以我们将mysql的配置文件复制到服务器上改了之后再复制回去，也可以将配置文件挂载到服务器上，过程我不多讲，只讲核心部分。

这里注意，如果你要删除容器重新挂载的话，请提前备份mysql数据，不然你就属于删库了
这里注意，如果你要删除容器重新挂载的话，请提前备份mysql数据，不然你就属于删库了
这里注意，如果你要删除容器重新挂载的话，请提前备份mysql数据，不然你就属于删库了
重要的话说三遍

在配置文件 /etc/mysql/mysql.conf.d/mysqld.cnf中添加

```shell
performance_schema_max_table_instances=400
table_definition_cache=400
table_open_cache=256
```

```shell
# 从容器中复制到服务器
docker cp mysql:/etc/mysql/mysql.conf.d/mysqld.cnf /dockerData/mysql
# 从服务器复制到容器
docker cp /dockerData/mysql/mysqld.cnf mysql:/etc/mysql/mysql.conf.d/mysqld.cnf
```

改完之后记得重启mysql，docker restart mysql

## 启动lute

此内容适用于solo3.6.5+

+ 启动Lute参考[Lute HTTP 使用指南](https://ld246.com/article/1569240189601)
+ 在solo启动参数末尾追加 `--lute_http=http://127.0.0.1:8249/--lute_http=http://localhost:8249/--lute_http=solo`成功启动后在终端输入 docker logs solo,日志显示有 luteAvailable=true即表示启用lute成功

## 采用Solo博客内置的cdn加速

```shell
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="123456" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true" \
    -v /skins/:/opt/solo/skins/	\
    --rm \
    b3log/solo --lute_http=http://127.0.0.1:8249  --listen_port=8080 --static_server_scheme=https --static_server_host=cdn.jsdelivr.net --static_server_port=  --static_path=/gh/88250/solo/src/main/resources    --server_scheme=https --server_host=zipblog.top --server_port=
```

## 拉取github上的[仓库](https://ld246.com/article/1557238327458)

现在似乎不支持，老是报错

![image.png](https://b3logfile.com/file/2021/09/image-d7558d42.png)

## 接入github可solo博客的第三方的评论系统

[似乎新版本的solo取消了内置的评论系统](https://ld246.com/article/1594988019287)，使用gittalk作为默认评论系统

> 文章转载声明：来自[`墨殇的技术博客`](https://www.inkdp.cn/articles/2019/08/06/1565021931775.html#%E6%95%B0%E6%8D%AE%E5%BA%93%E5%8D%A0%E7%94%A8%E5%86%85%E5%AD%98%E8%BF%87%E5%A4%A7%E4%BC%98%E5%8C%96)|[从零开始安装 solo 博客](https://www.inkdp.cn/articles/2019/08/06/1565021931775.html)
