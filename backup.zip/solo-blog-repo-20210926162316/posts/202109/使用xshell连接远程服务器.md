title: 使用xshell连接远程服务器
date: '2021-09-19 22:08:03'
updated: '2021-09-19 22:08:03'
tags: [xshell]
permalink: /articles/2021/09/19/1632060483078.html
---
[端口被封](https://segmentfault.com/q/1010000012654782/a-1020000012659467)

[解决方法](https://www.cnblogs.com/djjv/p/11973387.html)
