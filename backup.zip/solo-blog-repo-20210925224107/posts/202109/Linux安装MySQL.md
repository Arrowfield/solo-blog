title: Linux安装MySQL
date: '2021-09-25 19:49:38'
updated: '2021-09-25 20:21:41'
tags: [待分类]
permalink: /articles/2021/09/25/1632570578719.html
---
为了防止手残将docker中的数据库删掉了，因此我们使用服务器中自己的mysql，这样就可以进一步备份数据了。

[参考](https://www.cnblogs.com/jie1521/p/10286604.html)安装脚本如下

```shell
# 下载mysql
yum install mysql

# 安装mysql服务
yum install mysql-server

yum install mysql-devel

# 修改字符集
default-character-set=utf-8


#安装服务 
mysqld --install
# 初始化
mysqld --initialize-insecure
#开启数据库服务
net start mysql
#进入数据库
mysql -hlocalhost -uroot -p
#设置密码
set password for root@localhost = password('123456');
```
